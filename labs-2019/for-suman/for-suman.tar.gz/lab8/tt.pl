for ($i=700; $i>=400; $i-=6)
{
  $en = 1239 / $i;
  printf "$i %.2f\n",$en;
}

